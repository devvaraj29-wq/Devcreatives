Dev Creatives — Ready-to-deploy React + Tailwind portfolio
------------------------------------------------------------
Files:
- package.json
- tailwind.config.js
- postcss.config.js
- public/
- src/

How to deploy (recommended: Vercel or Netlify):
1. Download and unzip the project.
2. In project root run: npm install
3. Then: npm run build (or let Vercel/Netlify build automatically)
4. Deploy the folder to Vercel (New Project → Import → Upload).

Notes:
- Replace /public/images/* and src/components gallery image src paths with your real images.
- Tailwind is configured; if you prefer not to use Tailwind, you can replace styles in src/components/DevCreativesPortfolio.jsx.
