import DevCreativesPortfolio from './components/DevCreativesPortfolio';

export default function App() {
  return <DevCreativesPortfolio />;
}
